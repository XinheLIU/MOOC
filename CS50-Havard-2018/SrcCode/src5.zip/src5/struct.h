// Represents a student

typedef struct
{
    char *name;
    char *dorm;
}
student;
